#ifndef __IO_REDIRECT_H
#define __IO_REDIRECT_H

#include "parser.h"

void handle_io_redirect(cmd *c);

#endif